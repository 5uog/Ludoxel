# Copyright 2026 Kento Konishi (https://github.com/5uog)
# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from dataclasses import dataclass

from ..blocks.models.api import has_full_top_support_for_block
from ..blocks.registry.block_registry import BlockRegistry
from ..blocks.state.state_view import def_from_state, world_state_at
from ..blocks.structure.connectivity import collect_structural_neighbor_updates
from ..world.world_state import BlockKey, WorldState

GRAVITY_AFFECTED_TAG = "gravity_affected"


def _overlay_state_getter(world: WorldState, *, updates: dict[BlockKey, str], removals: set[BlockKey]):
    def get_state(x: int, y: int, z: int) -> str | None:
        key = (int(x), int(y), int(z))
        if key in removals:
            return None
        if key in updates:
            return str(updates[key])
        return world_state_at(world, int(x), int(y), int(z))

    return get_state


@dataclass(frozen=True)
class GravityStepResult:
    moved_cells: tuple[BlockKey, ...] = ()


@dataclass
class GravitySystem:
    block_registry: BlockRegistry

    def _is_gravity_affected(self, state_str: str | None) -> bool:
        defn = def_from_state(state_str, self.block_registry)
        if defn is None:
            return False
        return bool(defn.is_family("block") and defn.has_tag(GRAVITY_AFFECTED_TAG))

    def _has_top_support(self, world: WorldState, *, x: int, y: int, z: int, state_str: str, updates: dict[BlockKey, str], removals: set[BlockKey]) -> bool:
        get_state = _overlay_state_getter(world, updates=updates, removals=removals)
        return bool(has_full_top_support_for_block(str(state_str), get_state, self.block_registry.get, int(x), int(y), int(z)))

    def step(self, world: WorldState) -> GravityStepResult:
        pending_columns = world.consume_pending_gravity_columns()
        if not pending_columns:
            return GravityStepResult()

        updates: dict[BlockKey, str] = {}
        removals: set[BlockKey] = set()
        moved_cells: set[BlockKey] = set()
        get_state = _overlay_state_getter(world, updates=updates, removals=removals)

        for (x0, z0), min_y in sorted(pending_columns.items(), key=lambda item: (int(item[0][0]), int(item[0][1]), int(item[1]))):
            x = int(x0)
            z = int(z0)
            y_values = sorted(int(y) for y in world.snapshot_column(int(x), int(z)).keys())
            if not y_values:
                continue

            for y in y_values:
                if int(y) < int(min_y) - 1:
                    continue
                state_str = get_state(int(x), int(y), int(z))
                if not self._is_gravity_affected(state_str):
                    continue

                below_state = get_state(int(x), int(y - 1), int(z))
                if below_state is not None:
                    if self._has_top_support(world, x=int(x), y=int(y - 1), z=int(z), state_str=str(below_state), updates=updates, removals=removals):
                        continue
                    continue

                src = (int(x), int(y), int(z))
                dst = (int(x), int(y - 1), int(z))
                removals.add(src)
                updates[dst] = str(state_str)
                moved_cells.add(src)
                moved_cells.add(dst)

        if not moved_cells:
            return GravityStepResult()

        structural_updates = collect_structural_neighbor_updates(world, moved_cells, block_registry=self.block_registry, overlay_updates=updates, overlay_removals=removals)
        final_updates = dict(updates)
        final_updates.update(structural_updates)
        world.set_blocks_bulk(updates=final_updates, removals=removals)
        return GravityStepResult(moved_cells=tuple(sorted(moved_cells)))
